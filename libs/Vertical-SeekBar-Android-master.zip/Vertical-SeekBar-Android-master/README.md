Vertical-SeekBar-Android
========================

This project is all about Customizing the normal SeekBar to Vertical Seekbar. 